<?php
$dsn = 'mysql:host=localhost;dbname=pdo_db';
$username = 'root';
$password = 'zeyad111$';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Example of fetch()
    $stmt = $pdo->query("SELECT * FROM users");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo $row['name'] . "<br>";
    }

    // Example of fetchAll()
    $stmt = $pdo->query("SELECT * FROM users");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    print_r($rows);

    // Example of fetchColumn()
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "Total users: $count<br>";

    // Example of fetchObject()
    $stmt = $pdo->query("SELECT * FROM users");
    while ($user = $stmt->fetchObject()) {
        echo $user->name . "<br>";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>