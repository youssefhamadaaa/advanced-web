<?php
$dsn = 'mysql:host=localhost;dbname=pdo_db';
$username = 'root';
$password = 'zeyad111$';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Number of records per page
    $records_per_page = 20;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $records_per_page;

    // Fetch records
    $stmt = $pdo->prepare("SELECT * FROM users LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $records_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Display records
    foreach ($rows as $row) {
        echo $row['name'] . "<br>";
    }

    // Pagination links
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $total_records = $stmt->fetchColumn();
    $total_pages = ceil($total_records / $records_per_page);

    for ($i = 1; $i <= $total_pages; $i++) {
        echo "<a href='pagination.php?page=$i'>$i</a> ";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>